package Interfaces;

import java.lang.*;
import Classes.*;

public interface IloginOperation {
    void matchAdmin(String textField1, String textField2);

    void matchUser(String textField1, String textField2);
}
